/* wsr_menu_input - REBUILT to be piece.pdl METHOD-table-driven, per
 * direct instruction to research real TPMOS and "make the most proper
 * decisions" rather than keep hardcoded C option arrays (which the
 * user correctly identified as "just as inflexible" as a bad
 * hardcoded menu). Modeled directly on real TPMOS's own proven
 * pattern, researched this session:
 *   - `pieces/chtpm/plugins/chtpm_parser.c`'s `load_dynamic_methods()`
 *     reads a piece's own `piece.pdl` METHOD table and turns each row
 *     into a menu button - the menu doesn't exist anywhere except that
 *     one table.
 *   - `projects/fuzz-op/pieces/xlector/piece.pdl` is the real, live
 *     example: `METHOD | scan | pieces/apps/playrm/ops/+x/scan_op.+x
 *     xlector` etc - each row IS both the callable verb (this whole
 *     family's own existing METHOD-table convention, already used in
 *     mutaclsym) AND the menu entry, in one place.
 * This file is a much smaller, PAL-native equivalent of that same
 * core idea - NOT a port of chtpm_parser.c's full 3000+ lines (which
 * carry a great deal of wraith-alpha-desktop-specific complexity this
 * project doesn't need) - just the piece: read a piece.pdl's METHOD
 * rows, that's the menu, dispatch by row number.
 *
 * Adding a menu option now means adding one METHOD line to a
 * piece.pdl - no C recompilation, matching the real pattern this was
 * modeled on. Screens are pieces (`wsr_main_menu`, `wsr_financing_menu`
 * under projects/wsr-pal/pieces/) with their own piece.pdl - navigating
 * between them is a `GOTO:<piece_id>` command value, matching chtpm's
 * own `href`/`LAUNCH:` navigation convention in spirit.
 *
 * A small set of special command values are recognized (GOTO:/
 * TICK_ALL:/CYCLE_CORP/TOGGLE_TICKER/NEW_GAME/NEW_CORP/STUB); anything
 * else is shelled directly, matching chtpm_parser.c's own real
 * fallback behavior (`is_parser_cmd` check, `system()` otherwise) and
 * op-ed's `bind_event()`/`trigger_event()` precedent of running
 * whatever command a METHOD row names.
 *
 * Self-contained, no shared headers.
 * Usage: wsr_menu_input.+x <keycode> */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_LINE 512
#define MAX_PATH 4096
#define PATH_BUF (MAX_PATH + 256)
#define MAX_MENU_ITEMS 32

typedef struct {
    char label[128];
    char command[256];
} MenuItem;

static char project_root[MAX_PATH] = ".";

static void resolve_root(void) {
    const char *env = getenv("PRISC_PROJECT_ROOT");
    if (env && env[0]) snprintf(project_root, sizeof(project_root), "%s", env);
}

static int read_kv_int(const char *path, const char *key, int def) {
    FILE *f = fopen(path, "r");
    if (!f) return def;
    char line[MAX_LINE];
    int val = def;
    while (fgets(line, sizeof(line), f)) {
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq = '\0';
        if (strcmp(line, key) == 0) { val = atoi(eq + 1); break; }
    }
    fclose(f);
    return val;
}

static void read_kv_str(const char *path, const char *key, char *out, size_t out_sz) {
    out[0] = '\0';
    FILE *f = fopen(path, "r");
    if (!f) return;
    char line[MAX_LINE];
    size_t key_len = strlen(key);
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, key, key_len) == 0 && line[key_len] == '=') {
            char *v = line + key_len + 1;
            v[strcspn(v, "\n")] = '\0';
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat-truncation"
            snprintf(out, out_sz, "%s", v);
#pragma GCC diagnostic pop
            break;
        }
    }
    fclose(f);
}

static char *trim(char *s) {
    while (*s == ' ' || *s == '\t') s++;
    char *end = s + strlen(s) - 1;
    while (end > s && (*end == ' ' || *end == '\t' || *end == '\n' || *end == '\r')) *end-- = '\0';
    return s;
}

/* Same METHOD-line parsing shape as chtpm_parser.c's own
 * load_dynamic_methods() (strncmp "METHOD", split on '|' twice) - a
 * fresh, self-contained implementation here rather than including
 * that file, per this whole family's no-shared-headers doctrine. */
int load_menu_items(const char *project_root_, const char *piece_id, MenuItem *items, int max_items) {
    char pdl_path[PATH_BUF];
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat-truncation"
    snprintf(pdl_path, sizeof(pdl_path), "%s/projects/wsr-pal/pieces/%s/piece.pdl", project_root_, piece_id);
#pragma GCC diagnostic pop
    FILE *f = fopen(pdl_path, "r");
    if (!f) return 0;
    char line[MAX_LINE];
    int n = 0;
    while (n < max_items && fgets(line, sizeof(line), f)) {
        if (strncmp(line, "METHOD", 6) != 0) continue;
        char *p1 = strchr(line, '|');
        if (!p1) continue;
        char *p2 = strchr(p1 + 1, '|');
        if (!p2) continue;
        *p2 = '\0';
        char *label = trim(p1 + 1);
        char *command = trim(p2 + 1);
        snprintf(items[n].label, sizeof(items[n].label), "%s", label);
        snprintf(items[n].command, sizeof(items[n].command), "%s", command);
        n++;
    }
    fclose(f);
    return n;
}

static int count_corps(const char *project_root_) {
    char cmd[PATH_BUF];
    snprintf(cmd, sizeof(cmd), "ls '%s/projects/wsr-pal/pieces' 2>/dev/null | grep -c '^corp_'", project_root_);
    FILE *p = popen(cmd, "r");
    if (!p) return 0;
    int n = 0;
    if (fscanf(p, "%d", &n) != 1) n = 0;
    pclose(p);
    return n;
}

static void new_game(const char *project_root_) {
    char pieces_dir[PATH_BUF], template_dir[PATH_BUF];
    snprintf(pieces_dir, sizeof(pieces_dir), "%s/projects/wsr-pal/pieces", project_root_);
    snprintf(template_dir, sizeof(template_dir), "%s/projects/wsr-pal/pieces_template", project_root_);
    char cmd[(PATH_BUF + 32) * 2 + 16];
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat-truncation"
    snprintf(cmd, sizeof(cmd), "rm -rf '%s' && cp -r '%s' '%s'", pieces_dir, template_dir, pieces_dir);
#pragma GCC diagnostic pop
    int rc = system(cmd);
    (void)rc;

    /* Reset history cursor so the next process restart doesn't replay
     * the wiped history.txt from an old file position. */
    char cursor_state[PATH_BUF];
    snprintf(cursor_state, sizeof(cursor_state), "%s/projects/wsr-pal/pieces/apps/player_app/state.txt", project_root_);
    FILE *f = fopen(cursor_state, "w");
    if (f) {
        fputs("history_cursor=0\n", f);
        fclose(f);
    }
}

static void startup_new_corp(const char *project_root_, char *message_out, size_t message_out_sz) {
    static int counter = 1;
    char corp_dir_check[PATH_BUF];
    char ticker[16];
    do {
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat-truncation"
        snprintf(ticker, sizeof(ticker), "NEW%d", counter);
        snprintf(corp_dir_check, sizeof(corp_dir_check), "%s/projects/wsr-pal/pieces/corp_%s/state.txt", project_root_, ticker);
#pragma GCC diagnostic pop
        counter++;
    } while (access(corp_dir_check, F_OK) == 0 && counter < 1000);

    char cmd[PATH_BUF * 2];
    snprintf(cmd, sizeof(cmd), "cd '%s' && ./ops/+x/corp_ipo.+x %s 200 > /dev/null 2>&1", project_root_, ticker);
    int rc = system(cmd);
    if (rc == 0) {
        /* Real incorporation.c precedent (original source): founding a
         * corp makes the founder its 100% owner/shareholder - our
         * simplified equivalent is just setting owned_by, since we
         * don't track a full cap table. This was missing before - the
         * player could found a corp but never actually controlled it. */
        char owner_cmd[PATH_BUF * 2];
        snprintf(owner_cmd, sizeof(owner_cmd), "cd '%s' && ./ops/+x/corp_set_owner.+x corp_%s player_you > /dev/null 2>&1", project_root_, ticker);
        int rc2 = system(owner_cmd);
        (void)rc2;
    }
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat-truncation"
    if (rc == 0) snprintf(message_out, message_out_sz, "Started corp_%s with $200M seed capital - you are the owner.", ticker);
    else snprintf(message_out, message_out_sz, "Startup failed.");
#pragma GCC diagnostic pop
}

int main(int argc, char **argv) {
    if (argc < 2) return 1;
    int key = atoi(argv[1]);
    resolve_root();

    char state_path[PATH_BUF];
    snprintf(state_path, sizeof(state_path), "%s/projects/wsr-pal/pieces/wsr_menu/state.txt", project_root);
    int cursor = read_kv_int(state_path, "cursor", 1);
    int digit_accum = read_kv_int(state_path, "digit_accum", 0);
    int active_corp_index = read_kv_int(state_path, "active_corp_index", 0);
    int turn_number = read_kv_int(state_path, "turn_number", 0);
    int ticker_on = read_kv_int(state_path, "ticker_on", 0);
    char active_menu_piece[128];
    read_kv_str(state_path, "active_menu_piece", active_menu_piece, sizeof(active_menu_piece));
    if (!active_menu_piece[0]) snprintf(active_menu_piece, sizeof(active_menu_piece), "wsr_main_menu");

    /* If a wizard prompt is active (currently just Startup New Corp's
     * real 5-step flow - see wsr_wizard_input.c), EVERY key goes there
     * instead of normal menu dispatch, matching real cli_io's own
     * "active mode" exclusivity (researched directly against
     * chtpm_parser.c - once a cli_io element is active, key handling
     * branches entirely away from menu navigation until it exits). */
    int prompt_active = read_kv_int(state_path, "prompt_active", 0);
    if (prompt_active) {
        char wizard_cmd[PATH_BUF];
        snprintf(wizard_cmd, sizeof(wizard_cmd), "cd '%s' && ./ops/+x/wsr_wizard_input.+x %d", project_root, key);
        int rc = system(wizard_cmd);
        (void)rc;
        return 0;
    }

    MenuItem items[MAX_MENU_ITEMS];
    int item_count = load_menu_items(project_root, active_menu_piece, items, MAX_MENU_ITEMS);

    /* Arrow-key focus movement, SAME shape as real TPMOS's own
     * chtpm_parser.c (researched directly, not guessed - lines
     * 2609-2615 of pieces/chtpm/plugins/chtpm_parser.c): move
     * focus_index up/down with WRAPAROUND, `w`/`s` accepted as
     * synonyms for up/down (real chtpm_parser.c does this too, for
     * players without arrow keys / joystick-style input). */
    int is_up = (key == 1002 || key == 'w' || key == 'W');
    int is_down = (key == 1003 || key == 's' || key == 'S');

    /* REAL BUG FIX (found live via wsr.chtpm's own ${piece_methods}
     * switch, researched against real chtpm_parser.c's own
     * inject_raw_key() - pieces/chtpm/plugins/chtpm_parser.c lines
     * 1263-1320): chtpm's own nav-mode digit_accum ALREADY resolves
     * multi-digit menu selection (typing "1" then "3" moves ITS OWN
     * focus to item 13) entirely inside chtpm_parser_pal.c, before
     * anything is ever written here - Enter then fires
     * send_command("KEY:13") for that ALREADY-RESOLVED item exactly
     * once. inject_raw_key() writes the raw decimal value verbatim
     * either way (send_command()'s own KEY: handling ASCII-encodes
     * indices 1-9 as '0'+k purely so small menus look like an ordinary
     * typed digit keystroke to older non-chtpm code paths; 10+ is written
     * as the bare integer, since no single ASCII byte can represent two
     * digits). Either form arrives here as ONE fully-resolved selection,
     * never a partial keystroke to accumulate further - this project's
     * OWN digit_accum (built for raw multi-keystroke terminal typing,
     * before chtpm's own nav existed here) duplicates a job chtpm
     * already did upstream, and for indices >= 10 (whose raw value
     * doesn't fall in the '0'-'9' ASCII range at all) it did nothing but
     * silently drop the keypress, or - worse, for the two indices that
     * happen to collide with real ASCII control codes (10 = LF, 13 = CR)
     * - misfire as a stale Enter. Collapsed into one unified,
     * immediate-dispatch resolution: no accumulation, no waiting for a
     * separate Enter, since chtpm never sends a second event for the
     * same selection.
     *
     * REAL BUG FIX, LIVE-CONFIRMED (found via direct key injection, not
     * guessed - see pal-standards.txt §16.2's own test method): chtpm's
     * own load_dynamic_methods() (shared-ops/chtpm_parser_pal.c ~line
     * 992) starts its method_idx at 2, not 1 - it assumes a hand-authored
     * button already occupies nav slot 1 before ${piece_methods} (matching
     * mutaclsym's own "Control Hero" button, which DOES sit there).
     * wsr.chtpm has nothing before ${piece_methods} (the INTERACT gate
     * was removed - see §16), so chtpm's own onClick="KEY:n" is always
     * exactly ONE HIGHER than the piece.pdl's own 1-based METHOD row
     * order: confirmed live by resetting to wsr_main_menu, injecting the
     * raw value chtpm generates for the visually-13th row (14), and
     * observing active_menu_piece stay put (item 14, "Private", is a
     * no-op STUB - item 13, "Financing", a real GOTO, never fired).
     * Subtract 1 uniformly (both the ASCII-digit and raw-integer forms
     * carry the identical +1 offset, since it comes from method_idx, not
     * from either encoding) to realign with this project's own 1-based
     * piece.pdl row numbering. */
    int resolved_item = 0;
    if (key >= '0' && key <= '9') resolved_item = (key - '0') - 1;
    else if (key > 9 && key < 1000) resolved_item = key - 1;
    char message[MAX_LINE] = "";

    if (is_up) {
        cursor--;
        if (cursor < 1) cursor = item_count;
        digit_accum = 0;
    } else if (is_down) {
        cursor++;
        if (cursor > item_count) cursor = 1;
        digit_accum = 0;
    } else if (resolved_item >= 1 && resolved_item <= item_count) {
        cursor = resolved_item;
        {
            const char *cmd = items[cursor - 1].command;
            if (strncmp(cmd, "GOTO:", 5) == 0) {
                snprintf(active_menu_piece, sizeof(active_menu_piece), "%s", cmd + 5);
                cursor = 1;
                snprintf(message, sizeof(message), "-- %s --", active_menu_piece);
            } else if (strncmp(cmd, "TICK_ALL:", 9) == 0) {
                char tick_cmd[PATH_BUF];
                snprintf(tick_cmd, sizeof(tick_cmd), "cd '%s' && bash scripts/tick_all.sh %s > /dev/null 2>&1", project_root, cmd + 9);
                int rc = system(tick_cmd);
                (void)rc;
                turn_number++;
                snprintf(message, sizeof(message), "Turn advanced - the world moved forward.");
            } else if (strcmp(cmd, "CYCLE_CORP") == 0) {
                int corp_count = count_corps(project_root);
                if (corp_count > 0) active_corp_index = (active_corp_index + 1) % corp_count;
                snprintf(message, sizeof(message), "Switched active corporation.");
            } else if (strcmp(cmd, "TOGGLE_TICKER") == 0) {
                ticker_on = !ticker_on;
                snprintf(message, sizeof(message), "Ticker turned %s.", ticker_on ? "ON" : "OFF");
            } else if (strcmp(cmd, "NEW_GAME") == 0) {
                new_game(project_root);
                snprintf(active_menu_piece, sizeof(active_menu_piece), "wsr_main_menu");
                cursor = 1;
                active_corp_index = 0;
                turn_number = 0;
                snprintf(message, sizeof(message), "New game started - world reset to initial data.");
            } else if (strcmp(cmd, "NEW_CORP") == 0) {
                startup_new_corp(project_root, message, sizeof(message));
            } else if (strcmp(cmd, "START_WIZARD:new_corp") == 0) {
                /* Real 5-step Startup New Corp flow (industry/country/
                 * funding/name/ticker) - see wsr_wizard_input.c. Every
                 * subsequent key goes there until the wizard finishes
                 * or is cancelled (the prompt_active branch above). */
                digit_accum = 0;
                cursor = 1;
                FILE *sf = fopen(state_path, "w");
                if (sf) {
                    fprintf(sf, "cursor=%d\n", cursor);
                    fprintf(sf, "digit_accum=0\n");
                    fprintf(sf, "active_corp_index=%d\n", active_corp_index);
                    fprintf(sf, "turn_number=%d\n", turn_number);
                    fprintf(sf, "ticker_on=%d\n", ticker_on);
                    fprintf(sf, "active_menu_piece=%s\n", active_menu_piece);
                    fprintf(sf, "prompt_active=1\n");
                    fprintf(sf, "prompt_step=1\n");
                    fprintf(sf, "prompt_buffer=\n");
                    fprintf(sf, "last_message=Enter the industry number for your new corporation.\n");
                    fclose(sf);
                }
                return 0;
            } else if (strcmp(cmd, "STUB") == 0) {
                snprintf(message, sizeof(message), "Not yet available in this build.");
            } else if (strncmp(cmd, "RUN:", 4) == 0) {
                /* Real gameplay ops (trade/finance/management/loans/
                 * derivatives) print their own one-line result (bought/
                 * sold/insufficient cash/loan denied/etc) - capture it
                 * as the menu message instead of the generic "Ran: X"
                 * fallback below, so the player actually sees what
                 * happened, not just that something ran. */
                char raw_cmd[PATH_BUF * 2];
                snprintf(raw_cmd, sizeof(raw_cmd), "cd '%s' && %s 2>&1", project_root, cmd + 4);
                FILE *p = popen(raw_cmd, "r");
                if (p) {
                    if (!fgets(message, sizeof(message), p)) {
                        snprintf(message, sizeof(message), "Ran: %s", items[cursor - 1].label);
                    } else {
                        message[strcspn(message, "\n")] = '\0';
                    }
                    pclose(p);
                } else {
                    snprintf(message, sizeof(message), "Ran: %s", items[cursor - 1].label);
                }
            } else {
                /* Not a recognized special command - shell it directly,
                 * matching chtpm_parser.c's own real fallback and
                 * op-ed's bind_event()/trigger_event() precedent of
                 * running whatever a METHOD row names. */
                char raw_cmd[PATH_BUF * 2];
                snprintf(raw_cmd, sizeof(raw_cmd), "cd '%s' && %s > /dev/null 2>&1", project_root, cmd);
                int rc = system(raw_cmd);
                (void)rc;
                snprintf(message, sizeof(message), "Ran: %s", items[cursor - 1].label);
            }
        }
        digit_accum = 0;
    } else {
        digit_accum = 0;
    }

    FILE *f = fopen(state_path, "w");
    if (f) {
        fprintf(f, "cursor=%d\n", cursor);
        fprintf(f, "digit_accum=%d\n", digit_accum);
        fprintf(f, "active_corp_index=%d\n", active_corp_index);
        fprintf(f, "turn_number=%d\n", turn_number);
        fprintf(f, "ticker_on=%d\n", ticker_on);
        fprintf(f, "active_menu_piece=%s\n", active_menu_piece);
        fprintf(f, "last_message=%s\n", message);
        fclose(f);
    }

    /* CHTPM ${piece_methods} BRIDGE: chtpm_parser_pal.c's own
     * load_dynamic_methods() resolves project_id + active_target_id
     * (both read from pieces/apps/player_app/state.txt) into
     * projects/<project_id>/pieces/<active_target_id>/piece.pdl - the
     * EXACT SAME path/METHOD-row format load_menu_items() above already
     * reads. Writing these two fields here means chtpm auto-renders the
     * CURRENT screen's own menu as real, clickable numbered buttons (see
     * wsr.chtpm's own ${piece_methods} placeholder) with zero duplicate
     * menu-definition logic - one piece.pdl per screen, read by both this
     * op AND chtpm, always in sync since this write happens on every
     * keypress, the same moment active_menu_piece itself can change. */
    char chtpm_state_path[PATH_BUF];
    snprintf(chtpm_state_path, sizeof(chtpm_state_path), "%s/pieces/apps/player_app/state.txt", project_root);
    FILE *cf = fopen(chtpm_state_path, "w");
    if (cf) {
        fprintf(cf, "project_id=wsr-pal\n");
        fprintf(cf, "active_target_id=%s\n", active_menu_piece);
        fclose(cf);
    }
    return 0;
}
